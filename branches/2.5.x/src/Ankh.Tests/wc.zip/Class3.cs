using System;

namespace WindowsApplication
{
	/// <summary>
	/// Summary description for Class3.
	/// </summary>
	public class Class3
	{
		public Class3()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
