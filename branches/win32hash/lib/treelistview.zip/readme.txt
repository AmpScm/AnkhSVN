This code is taken from the article at http://www.codeproject.com/cs/miscctrl/treelistview.asp and
is written by Thomas Caudal.