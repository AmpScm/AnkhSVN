using System;

namespace GoogleOne
{
	/// <summary>
	/// Summary description for Test1.
	/// </summary>
	public class Test1
	{
		public Test1()
		{
			bla bla bla bla
		}
	}
}
